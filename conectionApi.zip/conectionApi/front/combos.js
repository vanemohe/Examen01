$(document).ready(function () {

    var url="https://localhost:44369/api/Brand";
    fetch(url).then(function(result){
       if(result.ok){
        return result.json();
       }
    }).then(function(data){
        data.forEach(function(element) {
            let marca=document.getElementById("marca");
            let opt=document.createElement("option");
            opt.appendChild(document.createTextNode(element.nombre));
            opt.value=element.Id;
            marca.appendChild(opt);
        });
    })

    //submarca
        $("#marca").change(function () { 
            $('#modelo').empty();
            $('#modelo').prepend('<option  value="0">Seleccione una opcion</option>');
            $('#descripcion').empty();
            $('#descripcion').prepend('<option  value="0">Seleccione una opcion</option>');
            var marca=$("#marca").val();
            var url2="https://localhost:44369/api/Subrand?id="+marca;
            fetch(url2).then(function(result){
            if(result.ok){
                return result.json();
            }
            }).then(function(data){
                    $('#submarca').empty();
                    $('#submarca').prepend('<option  value="0">Seleccione una opcion</option>');
                data.forEach(function(element) {
                    let marca=document.getElementById("submarca");
                    let opt=document.createElement("option");
                    
                    opt.appendChild(document.createTextNode(element.nombre_sub));
                    opt.value=element.Id_sub;
                    marca.appendChild(opt);
                });
            })
        })
    

        //submarca
        $("#submarca").change(function () { 
            $('#descripcion').empty();
            $('#descripcion').prepend('<option  value="0">Seleccione una opcion</option>');
            var submarca=$("#submarca").val();
            var url3="https://localhost:44369/api/Models?id="+submarca;
            fetch(url3).then(function(result){
            if(result.ok){
                return result.json();
            }
            }).then(function(data){
                    $('#modelo').empty();
                    $('#modelo').prepend('<option  value="0">Seleccione una opcion</option>');
                 
                data.forEach(function(element) {
                    let submarca=document.getElementById("modelo");
                    let opt=document.createElement("option");
                    opt.appendChild(document.createTextNode(element.nombre_model));
                    opt.value=element.id_modelo;
                    submarca.appendChild(opt);
                });
            })
        })

        $("#modelo").change(function () { 
            
            var modelo=$("#modelo").val();
            var submarca=$("#submarca").val();
            var url3="https://localhost:44369/api/Description";
            
            $.ajax({
                url: url3,
                type: 'GET',
                data: { id_sub: submarca,
                        id_mod : modelo },
                dataType: 'json',
                success: function (data) {
                    $('#descripcion').empty();
                    $('#descripcion').prepend('<option  value="0">Seleccione una opcion</option>');
                    console.log(data);
                    data.forEach(function(element) {
                        let descripcion=document.getElementById("descripcion");
                        let opt=document.createElement("option");
                        opt.appendChild(document.createTextNode(element.descripcion));
                        opt.value=element.DescripcionId;
                        descripcion.appendChild(opt);
                    });
                 },
                 statusCode: {
                          404: function () {
                               alert('Failed');
                               }
                }
           });
           
        })


        //Mandando llamar la funcion al terminar de escribir 

var controladorTiempo = "";

function codigoAJAX() {
    
    var sZip=$("#cp").val();
    var result=isValidUSZip(sZip);
    if(result == true){
        var url3="https://web.aarco.com.mx/api-examen/api/examen/sepomex/"+sZip;
        $.ajax({
            url: url3,
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                datos=data.CatalogoJsonString;            
                var b=jQuery.parseJSON( datos );
                console.log(b[0]);
                const municipio=b[0];
                let datos_municipio=municipio.Municipio;
                let municipio_perteneciente=datos_municipio.sMunicipio;
                let estado=datos_municipio.Estado;
                let estado_perteneciente=estado.sEstado
                //Colonias
                let lst_colonias=municipio.Ubicacion;
                $('#estado').val("");
                $('#municipio').val("");
                $('#colonia').empty();
                $('#colonia').prepend('<option  value="0">Seleccione una opcion</option>');
                for(let colonia of lst_colonias){
                   $("#colonia").append("<option value="+ colonia.iIdUbicacion +">"+ colonia.sUbicacion +"</option>");

                }
                //console.log(lst_colonias);
                $('#estado').val(estado_perteneciente);
                $('#municipio').val(municipio_perteneciente);
                
             },
             statusCode: {
                      404: function () {
                           alert('Failed');
                           }
            }
       }); 
    }
    else
    {
        alert("El codigo postal no es correcto");
    }
}

$("#cp").on("keyup", function() {
    clearTimeout(controladorTiempo);
    controladorTiempo = setTimeout(codigoAJAX, 4000);
    
});



        
});

function isValidUSZip(sZip) {
   return /^\d{5}(-\d{4})?$/.test(sZip);
}

function ValidaSoloNumeros() {
    if ((event.keyCode < 48) || (event.keyCode > 57)) 
       event.returnValue = false;
  }