
$(document).ready(function () {

   $("#enviar").click(function(){

      let marca=$("#marca").val();
      let submarca=$("#submarca").val();
      let modelo=$("#modelo").val();
      let descripcion=$("#descripcion").val();
      let codigopostal=$("#cp").val();
      
      let colonia=$("#colonia").val();
       
      if (marca == 0) {
        $(".marca").html("La marca es requerida");
        return false;
      }
      else {
            $(".marca").html("");
      }

      if (submarca == 0) {
        $(".submarca").html("La submarca es requerida");
        return false;
      }
      else {
            $(".submarca").html("");
      }

      if (modelo == 0) {
        $(".modelo").html("La submarca es requerida");
        return false;
      }
      else {
            $(".modelo").html("");
      }

      if (descripcion == 0) {
        $(".descripcion").html("La descripcion es requerida");
        return false;
      }
      else {
            $(".descripcion").html("");
      }

      if (codigopostal.length == 0) {
        $(".cp").html("El campo código postal es requerido");
        return false;
    }
    else {
        $(".cp").html("");
    }

    if (colonia == 0) {
        $(".colonia").html("La colonia es requerida");
        return false;
      }
      else {
            $(".colonia").html("");
      }

      $('#myModal').modal('show');
     

    var url="https://web.aarco.com.mx/api-examen/api/examen/crear-peticion";  
      
    $.ajax({
        url: url,
        type: 'POST',
        data: { DescripcionId: descripcion},
        dataType: 'json',
        success: function (data) {
           let clave=data;
           console.log(clave);
           localStorage.setItem('clave', clave);
            
           var url2="https://web.aarco.com.mx/api-examen/api/examen/peticion/"+clave;  

            $.ajax({
                url: url2,
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                var respuesta=data;
                console.log(respuesta)
                var clave=localStorage.getItem('clave');
                localStorage.setItem('peticionTerminada', respuesta.PeticionFinalizada);
              
                var peticionFinalizada=setInterval(
                        function () { 
                                var url3="https://web.aarco.com.mx/api-examen/api/examen/peticion/"+clave; 
                                $.ajax({
                                    url: url3,
                                    type: 'GET',
                                    dataType: 'json',
                                    success: function (data) {
                                        if(data.PeticionFinalizada==true){
                                            clearInterval(peticionFinalizada);
                                            let a=0;
                                            let b=0;
                                            let aseguradorasArr=data.aseguradoras;
                                            var imagen="";
                                            let tarifa=0;
                                            let cotizacion=0;
                                            $("#tarifas").html("");
                                            for(let seguradora of aseguradorasArr){
                                                b=seguradora.AseguradoraId
                                                console.log(b);
                                                
                                                 
                                                switch(b){
                                                    case 1:
                                                        imagen="<img id=\"image_aseguradora\" src=\"assets/AXA.png\" style=\"width:100%\">";
                                                        break;
                                                    case 2:
                                                        imagen="<img id=\"image_aseguradora\" src=\"assets/CHUBB.png\" style=\"width:100%\">";
      
                                                        break;
                                                    case 3:
                                                        imagen="<img id=\"image_aseguradora\" src=\"assets/ZURICH.png\" style=\"width:100%\">";
                                                   
                                                        break;
                                                    case 4:
                                                        imagen="<img id=\"image_aseguradora\" src=\"assets/QUALITAS.png\" style=\"width:100%\">";
                                                      
                                                        break;  
                                                    case 5:
                                                        imagen="<img id=\"image_aseguradora\" src=\"assets/HDI.png\" style=\"width:100%\">";
                                                          
                                                        break;            
                                                }
                                                tarifa=seguradora.Tarifa;
                                                console.log(tarifa);
                                                cotizacion=tarifa.toLocaleString('en');
                                                console.log(cotizacion);
                                                $("#tarifas").append("<div class=\"col-lg-2 col-md-2\">"+
                                                 "<div class=\"panel panel-primary\" style=\"margin-top:35px\">"+
                                                 "<div class=\"panel-heading\"></div>"+
                                                 "<div class=\"panel-body\">"+ imagen +
                                                "<div id=\"info\"><p style=\"text-align:center\"><strong>$"+ cotizacion +"</strong></p></div>"+
                                                "</div></div></div></div>");
                                                
                                                
                                                
                                            }
                                            $('#myModal').modal('hide');

                                        }
                                        

                                    },
                                    statusCode: {
                                    404: function () {
                                        alert('Failed');
                                        }
                                    }
                                });     
                             
                
                         }, 5000);    
                
                     
                },
                 statusCode: {
                    404: function () {
                        alert('Failed');
                        }
                }

            });
        }
   
     });

   });   
}); 


   