<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Form Cotización</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/styles.css">
    
  </head>
  <body>
   <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
            <a class="navbar-brand" href="#">
                Examen 
            </a>
            </div>
        </div>
    </nav>
    <div class="container">
    <div class="row">
        <div class="col-md-6">
        <form class="form-horizontal" id="cotizacion_seguro">
            <div class="form-group">
                <label class="col-sm-12">Marca: </label>
                <div class="col-sm-12">
                    <select class="form-control" id="marca" name="marca">
                        <option value="0">selecciona una opción</option>
                    </select>
                    <span class="text-danger marca"></span>
                </div>

            </div>
            <div class="form-group">
                <label class="col-sm-12 ">Submarca: </label>
                <div class="col-sm-12">
                    <select class="form-control" id="submarca" name="submarca">
                        <option value="0">selecciona una opción</option>
                    </select>
                    <span class="text-danger submarca"></span>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12 ">Modelo: </label>
                <div class="col-sm-12">
                    <select class="form-control" id="modelo" name="modelo">
                        <option value="0">selecciona una opción</option>
                    </select>
                    <span class="text-danger modelo"></span>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12">Descripción: </label>
                <div class="col-sm-12">
                    <select class="form-control" id="descripcion" name="descripcion">
                        <option value="0" >selecciona una opción</option>
                    </select>
                    <span class="text-danger descripcion"></span>
                </div>
            </div>
       
    </div>
    <div class="col-md-6">
    
            <div class="form-group">
                <label class="col-sm-12">Codigo Postal: </label>
                <div class="col-sm-12">
                     <input type="text" name="cp" id="cp"  class="form-control"  onkeypress="ValidaSoloNumeros();">
                </div> 
                <span class="text-danger cp"></span>    
            </div>
            
            <div class="form-group" >
                <label class="col-sm-12" style="padding-top:15px">Estado: </label>
                <div class="col-sm-12">
                <input type="text" name="estado"  class="form-control" id="estado" disabled>
                
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12" style="padding-top:15px">Municipio: </label>
                <div class="col-sm-12">
                    <input type="text" name="municipio"  class="form-control" id="municipio" disabled>
                </div>
            </div>
            <div class="form-group">
                <label class="col-sm-12" style="padding-top:15px">Colonia: </label>
                <div class="col-sm-12">
                    <select class="form-control" id="colonia" name="colonia">
                        <option>selecciona una opción</option>
                    </select>
                    <span class="text-danger colonia"></span>  
                </div>
            </div>
            <br/><br/>
            <div class="form-group">
             <div class="col-sm-12" style="padding-top:25px;text-align: end;">
               <button type="button" id="enviar" class="btn btn-primary">Enviar</button>
             </div>
            </div>
        </form>
    </div>
        </div>
        <div class="row" id="tarifas">    
       </div><!--Fin div-->  


<!--Modal-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
     
      <div class="modal-body">
      <div class="loading"><div class="alert alert-primary" role="alert"><img src="assets/loading.gif" width="100%"/><br/>Procesando, por favor espere...</div></div>
      </div>
      
    </div>
  </div>
</div>




    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js" ></script>
    <script src="front/combos.js"></script>
    <script src="front/validar.js"></script>


  </body>
</html>